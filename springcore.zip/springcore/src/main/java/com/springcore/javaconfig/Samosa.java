package com.springcore.javaconfig;

public class Samosa {

	void display() {
		System.out.println("my price is little be high");
		
	}
	
}
